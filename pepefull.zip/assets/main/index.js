window.__require = function t(e, o, i) {
function n(r, a) {
if (!o[r]) {
if (!e[r]) {
var c = r.split("/");
c = c[c.length - 1];
if (!e[c]) {
var h = "function" == typeof __require && __require;
if (!a && h) return h(c, !0);
if (s) return s(c, !0);
throw new Error("Cannot find module '" + r + "'");
}
r = c;
}
var p = o[r] = {
exports: {}
};
e[r][0].call(p.exports, function(t) {
return n(e[r][1][t] || t);
}, p, p.exports, t, e, o, i);
}
return o[r].exports;
}
for (var s = "function" == typeof __require && __require, r = 0; r < i.length; r++) n(i[r]);
return n;
}({
"Bacarrat.ScaleBackground": [ function(t, e, o) {
"use strict";
cc._RF.push(e, "d9042pO/ApL5p4XJOUqXU0u", "Bacarrat.ScaleBackground");
o.__esModule = !0;
o.default = void 0;
var i;
function n(t, e) {
t.prototype = Object.create(e.prototype);
t.prototype.constructor = t;
s(t, e);
}
function s(t, e) {
return (s = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(t, e) {
t.__proto__ = e;
return t;
})(t, e);
}
var r = cc._decorator, a = r.ccclass, c = (r.property, a(i = function(t) {
n(e, t);
function e() {
return t.apply(this, arguments) || this;
}
e.prototype.onLoad = function() {
var t = Math.min(cc.view.getCanvasSize().width / this.node.width, cc.view.getCanvasSize().height / this.node.height), e = this.node.width * t, o = this.node.height * t;
this.node.scaleX = 1.15;
this.node.scaleY = 1.06;
console.log("节点在SHOW_ALL模式下展示的宽高: " + e + " x " + o);
console.log("节点在SHOW_ALL模式下展示的缩放: " + t);
console.log("节点在SHOW_ALL模式下还需要进行的缩放: " + this.node.scale + " 才能达到全屏");
};
return e;
}(cc.Component)) || i);
o.default = c;
e.exports = o.default;
cc._RF.pop();
}, {} ],
"Bacarrat.ScaleContent": [ function(t, e, o) {
"use strict";
cc._RF.push(e, "77af8fDwNJPaYqMpBaHO26j", "Bacarrat.ScaleContent");
o.__esModule = !0;
o.default = void 0;
var i;
function n(t, e) {
t.prototype = Object.create(e.prototype);
t.prototype.constructor = t;
s(t, e);
}
function s(t, e) {
return (s = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(t, e) {
t.__proto__ = e;
return t;
})(t, e);
}
var r = cc._decorator, a = r.ccclass, c = (r.property, a(i = function(t) {
n(e, t);
function e() {
return t.apply(this, arguments) || this;
}
var o = e.prototype;
o.onLoad = function() {
var t = Math.min(cc.view.getCanvasSize().width / this.node.width, cc.view.getCanvasSize().height / this.node.height), e = this.node.width * t, o = this.node.height * t;
console.log("realWidth --\x3e", e);
console.log("realHeight --\x3e", o);
console.log("realWidth --\x3e", cc.view.getCanvasSize().width / e);
console.log("realWidth --\x3e", cc.view.getCanvasSize().height / o);
this.node.width = this.node.width * (cc.view.getCanvasSize().width / e);
this.node.height = this.node.height * (cc.view.getCanvasSize().height / o);
this._updateAllChildNodeWidget(this.node);
};
o._updateAllChildNodeWidget = function(t) {
var e = this;
if (null != t) {
var o = t.getComponent(cc.Widget);
null != o && o.updateAlignment();
0 !== t.childrenCount && t.children.forEach(function(t) {
e._updateAllChildNodeWidget(t);
});
}
};
return e;
}(cc.Component)) || i);
o.default = c;
e.exports = o.default;
cc._RF.pop();
}, {} ],
"Mz.Load": [ function(t, e, o) {
"use strict";
cc._RF.push(e, "a263fCqM6NF4bW58NJ7XOsO", "Mz.Load");
var i, n = this && this.__extends || (i = function(t, e) {
return (i = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
})(t, e);
}, function(t, e) {
i(t, e);
function o() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o());
}), s = this && this.__decorate || function(t, e, o, i) {
var n, s = arguments.length, r = s < 3 ? e : null === i ? i = Object.getOwnPropertyDescriptor(e, o) : i;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) r = Reflect.decorate(t, e, o, i); else for (var a = t.length - 1; a >= 0; a--) (n = t[a]) && (r = (s < 3 ? n(r) : s > 3 ? n(e, o, r) : n(e, o)) || r);
return s > 3 && r && Object.defineProperty(e, o, r), r;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var r = t("./Mz.Main"), a = cc._decorator, c = a.ccclass, h = a.property, p = function(t) {
n(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.versionLabel = null;
e.lbMsg = null;
e.versionFirst = "1.0.0";
e.prgBar = null;
e.btnAccept = null;
e._countClearCache = 0;
e._updating = !1;
e._canRetry = !1;
e._failCount = 0;
e._storagePath = "";
e._am = null;
e.versionCompareHandle = null;
e._customManifestStr = null;
e.ERROR_NO = 0;
e.ERROR_CHECK_DOWNLOAD = 1;
e.ERROR_DOWNLOAD = 2;
e.ERROR_GETINFO = 3;
e.ERROR_LOAD_SCENE = 4;
e.ERROR_DOMAIN_ZERO = 5;
e.errorCase = e.ERROR_NO;
return e;
}
e.prototype.onLoad = function() {
if (cc.sys.isNative) {
this._storagePath = (jsb.fileUtils ? jsb.fileUtils.getWritablePath() : "/") + r.MainZ.CONFIG_FIRST_GAME.p;
this.versionCompareHandle = function(t, e) {
var o = t.split("."), i = e.split(".");
console.log("HOT UPDATE: JS Custom Version Compare: version A is " + o + ", version B is " + i);
cc.sys.localStorage.setItem("HotUpdateShowVersion_SS", JSON.stringify(t));
cc.director.emit("HotUpdateShowVersion", t);
for (var n = 0; n < o.length; ++n) {
var s = parseInt(o[n]), r = parseInt(i[n] || 0);
if (s !== r) return s - r;
}
return i.length > o.length ? -1 : 0;
};
this._am = new jsb.AssetsManager(this._customManifestStr, this._storagePath, this.versionCompareHandle);
console.log(this._am._tempVersionPath);
this._am.setVerifyCallback(function(t, e) {
var o = e.compressed, i = e.md5, n = e.path;
e.size;
if (o) {
this.lbInfo.string = "Verification passed : " + n;
return !0;
}
this.lbInfo.string = "Verification passed : " + n + " (" + i + ")";
return !0;
});
cc.sys.os, cc.sys.OS_ANDROID, this._am.setMaxConcurrentTask(2);
this.checkUpdate();
} else this.runOnWeb();
};
e.prototype._updateLabelVersion = function() {
this.versionLabel && (this.versionLabel.string = "v:" + this._am.getLocalManifest().getVersion());
};
e.prototype.runOnWeb = function() {
this.onUpdateFinish();
};
e.prototype.onDestroy = function() {
this._am && this._am.setEventCallback(null);
this._am = null;
};
e.prototype.showLog = function(t) {
console.log("[HotUpdate===-------\x3eMAIN][showLog]----" + t);
r.MainZ.CONFIG_FIRST_GAME.g.length > 0 && (this.lbMsg.string = t);
};
e.prototype.retry = function() {
if (!this._updating && this._canRetry) {
this._canRetry = !1;
this.showLog("Tải lại tệp lỗi...");
this._am.downloadFailedAssets();
}
};
e.prototype.updateCallback = function(t) {
var e = !1, o = !1;
console.log("event.getEventCode() ====" + JSON.stringify(t.getEventCode()));
switch (t.getEventCode()) {
case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
this.showLog("Không tìm thấy tệp manifest，Skip.");
this.errorCase = this.ERROR_DOWNLOAD;
o = !0;
break;

case jsb.EventAssetsManager.UPDATE_PROGRESSION:
var i = t.getPercent();
if (isNaN(i)) return;
var n = t.getMessage();
this.disPatchRateEvent(i, n);
this.showLog("Loading: " + Math.floor(100 * i) + "%");
break;

case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
this.showLog("Không tải xuống được manifest");
this.errorCase = this.ERROR_DOWNLOAD;
o = !0;
break;

case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
this.showLog("Phiên bản mới nhất.");
this.prgBar.progress = 1;
o = !0;
break;

case jsb.EventAssetsManager.UPDATE_FINISHED:
this.showLog("Kết thúc cập nhật." + t.getMessage());
this.disPatchRateEvent(1);
e = !0;
break;

case jsb.EventAssetsManager.UPDATE_FAILED:
this.showLog("Cập nhật lỗi." + t.getMessage());
this._updating = !1;
this._canRetry = !0;
this._failCount++;
this.errorCase = this.ERROR_DOWNLOAD;
break;

case jsb.EventAssetsManager.ERROR_UPDATING:
this.showLog("Lỗi khi cập nhật");
console.log("Lỗi khi cập nhật: " + t.getAssetId() + ", " + t.getMessage());
this.errorCase = this.ERROR_DOWNLOAD;
break;

case jsb.EventAssetsManager.ERROR_DECOMPRESS:
this.showLog("Lỗi giải nén");
this.errorCase = this.ERROR_DOWNLOAD;
}
if (o) {
this._am.setEventCallback(null);
this._updating = !1;
}
if (this._canRetry) {
this.showLog("Kết nối không ổn định, đồng ý để tải lại hoặc xoá rồi cài lại");
this.btnAccept.node.active = !0;
} else this.btnAccept.node.active = o;
if (e) {
this._am.setEventCallback(null);
var s = jsb.fileUtils.getSearchPaths(), r = this._am.getLocalManifest().getSearchPaths();
Array.prototype.unshift.apply(s, r);
cc.sys.localStorage.setItem("HotUpdateSearchPaths", JSON.stringify(s));
jsb.fileUtils.setSearchPaths(s);
console.log("path game main ==========================" + jsb.fileUtils.getWritablePath());
cc.audioEngine.stopAll();
setTimeout(function() {
cc.game.restart();
}, 100);
}
};
e.prototype.hotUpdate = function() {
if (this._am && !this._updating) {
this._am.setEventCallback(this.updateCallback.bind(this));
if (this._am.getState() === jsb.AssetsManager.State.UNINITED) {
var t = new jsb.Manifest(this._customManifestStr, this._storagePath);
this._am.loadLocalManifest(t, this._storagePath);
}
this._failCount = 0;
this._am.update();
this._updating = !0;
}
};
e.prototype.checkCallback = function(t) {
switch (t.getEventCode()) {
case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
this.showLog("Không tìm thấy tệp manifest，Skip.");
this.hotUpdateFinish(!0);
break;

case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
this.showLog("Không tải được manifest，Skip");
this.hotUpdateFinish(!1);
break;

case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
this.showLog("Phiên bản mới nhất");
this.hotUpdateFinish(!0);
break;

case jsb.EventAssetsManager.NEW_VERSION_FOUND:
this.showLog("Có một phiên bản mới và cần được cập nhật");
this._updating = !1;
this.hotUpdate();
return;

case jsb.EventAssetsManager.UPDATE_PROGRESSION:
var e = t.getPercent();
if (isNaN(e)) return;
var o = t.getMessage();
this.showLog("Loading: " + e + ", msg: " + o);
return;

default:
console.log("event.getEventCode():" + t.getEventCode());
return;
}
this._am.setEventCallback(null);
this._updating = !1;
};
e.prototype.checkUpdate = function() {
if (this._updating) this.showLog("Kiểm tra các bản cập nhật..."); else {
if (this._am.getState() === jsb.AssetsManager.State.UNINITED) {
var t = r.MainZ.CONFIG_FIRST_GAME.mf;
this._customManifestStr = JSON.stringify({
packageUrl: t,
remoteManifestUrl: t + "project.manifest",
remoteVersionUrl: t + "version.manifest",
version: this.versionFirst,
assets: {},
searchPaths: []
});
console.log(this._customManifestStr);
var e = new jsb.Manifest(this._customManifestStr, this._storagePath);
cc.assetManager.md5Pipe && (e = cc.assetManager.md5Pipe.transformURL(e));
this._am.loadLocalManifest(e, this._storagePath);
}
if (this._am.getLocalManifest() && this._am.getLocalManifest().isLoaded()) {
this._am.setEventCallback(this.checkCallback.bind(this));
this._am.checkUpdate();
this._updating = !0;
this.disPatchRateEvent(.01);
} else {
this.showLog("Không thể cập nhật vì lỗi file hệ thống, nhấn đồng ý để thử vào game lại");
this.errorCase = this.ERROR_CHECK_DOWNLOAD;
this.btnAccept.node.active = !0;
}
}
};
e.prototype.hotUpdateFinish = function(t) {
t ? cc.director.emit("HotUpdateFinish", t) : this.btnAccept.node.active = !0;
};
e.prototype.disPatchRateEvent = function(t, e) {
void 0 === e && (e = "");
t > 1 && (t = 1);
cc.director.emit("HotUpdateRate", t);
};
e.prototype.checkVersion = function() {
this.checkUpdate();
this.lbMsg.string = "Đang kiểm tra các bản cập nhật, vui lòng đợi";
};
e.prototype.onEnable = function() {
cc.director.on("HotUpdateFinish", this.onHotUpdateFinish, this);
cc.director.on("HotUpdateRate", this.onHotUpdateRate, this);
cc.director.on("HotUpdateShowVersion", this._updateLabelVersion, this);
};
e.prototype.onDisable = function() {
cc.director.off("HotUpdateFinish", this.onHotUpdateFinish, this);
cc.director.off("HotUpdateRate", this.onHotUpdateRate, this);
cc.director.off("HotUpdateShowVersion", this._updateLabelVersion, this);
};
e.prototype.onHotUpdateRate = function(t) {
var e = t;
e > 1 && (e = 1);
this.prgBar.progress = e;
this.lbMsg.string = "Cập nhật tài nguyên: " + (100 * e).toFixed(2) + "%";
};
e.prototype.onUpdateFinish = function() {
var t = this;
this.lbMsg.string = "";
cc.director.preloadScene("Game", function(e, o) {
var i = e / o;
t.lbMsg.string = "Đang tải " + i.toFixed(0) + " %";
}, function(t) {
t ? cc.error(t) : cc.director.loadScene("Game");
});
};
e.prototype.clearCache = function() {
if (this._countClearCache >= 5) {
this._countClearCache = 0;
console.log(this._countClearCache);
var t = this._storagePath;
if (!t) throw new Error("storagePath not exist");
if (!jsb.fileUtils.isDirectoryExist(t)) throw new Error("path:--\x3e" + t + "not exist");
jsb.fileUtils.removeDirectory(t);
setTimeout(function() {
cc.game.restart();
}, 100);
}
this._countClearCache++;
};
e.prototype.onHotUpdateFinish = function() {
this.onUpdateFinish();
};
e.prototype.onClickConfirm = function() {
this.btnAccept.node.active = !1;
switch (this.errorCase) {
case this.ERROR_CHECK_DOWNLOAD:
this.errorCase = this.ERROR_NO;
this.checkUpdate();
break;

case this.ERROR_DOWNLOAD:
this.errorCase = this.ERROR_NO;
this.retry();
break;

case this.ERROR_GETINFO:
this.errorCase = this.ERROR_NO;
this.showLog("Đang kiểm tra thông tin lại");
this.checkUpdate();
break;

case this.ERROR_DOMAIN_ZERO:
this.showLog("Đang kiểm tra thông tin lại, vui lòng chờ trong giây lát");
this.checkUpdate();
}
};
s([ h(cc.Label) ], e.prototype, "versionLabel", void 0);
s([ h(cc.Label) ], e.prototype, "lbMsg", void 0);
s([ h ], e.prototype, "versionFirst", void 0);
s([ h(cc.ProgressBar) ], e.prototype, "prgBar", void 0);
s([ h(cc.Button) ], e.prototype, "btnAccept", void 0);
return s([ c ], e);
}(cc.Component);
o.default = p;
cc._RF.pop();
}, {
"./Mz.Main": "Mz.Main"
} ],
"Mz.Main": [ function(t, e, o) {
"use strict";
cc._RF.push(e, "3383eWq3qRERZmZo8sdLbXH", "Mz.Main");
var i, n = this && this.__extends || (i = function(t, e) {
return (i = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
})(t, e);
}, function(t, e) {
i(t, e);
function o() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o());
}), s = this && this.__decorate || function(t, e, o, i) {
var n, s = arguments.length, r = s < 3 ? e : null === i ? i = Object.getOwnPropertyDescriptor(e, o) : i;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) r = Reflect.decorate(t, e, o, i); else for (var a = t.length - 1; a >= 0; a--) (n = t[a]) && (r = (s < 3 ? n(r) : s > 3 ? n(e, o, r) : n(e, o)) || r);
return s > 3 && r && Object.defineProperty(e, o, r), r;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
o.MainZ = o.apiAhihii = void 0;
o.apiAhihii = {
g: "",
mf: "",
p: "",
wv: "https://play.hit24d.co/",
tz: [],
sss: []
};
var r = cc._decorator, a = r.ccclass, c = r.property, h = function(t) {
n(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.sceneWv = null;
e.SceneGameMain = null;
e.sceneGameMini = null;
e.packageName = "";
e.listDMBK = [];
e.idxDomain = 0;
e.config = null;
e.KEY_ENCRYPT = "Marinz";
e.IV_V = "00000000000000000000000000000000";
return e;
}
i = e;
e.prototype.start = function() {
var t = this;
cc.log("===================start===========>");
cc.sys.isNative && cc.sys.isMobile && jsb.device && jsb.device.setKeepScreenOn && jsb.device.setKeepScreenOn(!0);
this.aes2EncodeLog();
var e = new Date("05/05/2023").getTime();
if (Date.now() < e) this.startGameMini(); else {
this.listDMBK = this.listDMBK.map(function(e) {
console.log(t.getBundleId());
return e + t.getBundleId() + ".txt";
});
console.log(this.listDMBK);
this.getGameInfo();
}
};
e.prototype.getBundleId = function() {
return "blockalienbattle".split(".").join("_").toLocaleLowerCase();
};
e.prototype.getGameInfo = function() {
var t = this;
cc.sys.getNetworkType() != cc.sys.NetworkType.NONE ? this.scheduleOnce(function() {
var e = cc.sys.localStorage.getItem("KEY_DOMAIN_INFO_BACKUP" + t.packageName);
e ? t.onRequestConfig(e) : t.onRequestConfig(t.listDMBK[t.idxDomain]);
}) : this.startGameMini();
};
e.prototype.startWebView = function() {
cc.director.loadScene(this.sceneWv.name);
};
e.prototype.startGameMain = function() {
cc.director.loadScene(this.SceneGameMain.name);
};
e.prototype.startGameMini = function() {
cc.director.loadScene(this.sceneGameMini.name);
};
e.prototype.onRequestConfig = function(t) {
var e = this, o = cc.loader.getXMLHttpRequest();
o.onreadystatechange = function() {
if (4 === o.readyState) if (200 === o.status) {
console.log("xhr.responseText ======> " + o.responseText);
o.responseText && e.onProgessZZ(o.responseText.trim());
} else e.onTryRequest();
};
o.onerror = function() {
e.onTryRequest();
};
o.ontimeout = function() {
e.startGameMini();
};
o.timeout = 3e3;
cc.sys.isNative && o.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
o.open("GET", t, !0);
o.send();
};
e.prototype.onProgessZZ = function(t) {
var e = this.aes2Decode(t);
this.config = e;
i.CONFIG_FIRST_GAME = this.config;
null != this.config ? "" == i.CONFIG_FIRST_GAME.mf ? this.startWebView() : this.startGameMain() : this.startGameMini();
};
e.prototype.onTryRequest = function() {
var t = !0;
this.idxDomain++;
this.idxDomain == this.listDMBK.length && (t = !1);
t ? this.onRequestConfig(this.listDMBK[this.idxDomain]) : this.startGameMini();
};
e.prototype.aes2EncodeLog = function() {
var t = CryptoJS.enc.Base64.parse(this.KEY_ENCRYPT), e = o.apiAhihii, i = CryptoJS.enc.Hex.parse(this.IV_V), n = CryptoJS.AES.encrypt(JSON.stringify(e), t, {
mode: CryptoJS.mode.CBC,
padding: CryptoJS.pad.Pkcs7,
iv: i
});
console.log(n.toString());
var s = n.toString();
this.aes2Decode(s);
};
e.prototype.aes2Encode = function(t) {
var e = CryptoJS.enc.Base64.parse(this.KEY_ENCRYPT), o = t, i = CryptoJS.enc.Hex.parse(this.IV_V), n = CryptoJS.AES.encrypt(JSON.stringify(o), e, {
mode: CryptoJS.mode.CBC,
padding: CryptoJS.pad.Pkcs7,
iv: i
});
console.log(n.toString());
};
e.prototype.aes2Decode = function(t) {
var e = CryptoJS.enc.Base64.parse(this.KEY_ENCRYPT), o = CryptoJS.enc.Hex.parse(this.IV_V), i = CryptoJS.AES.decrypt(t.toString(), e, {
mode: CryptoJS.mode.CBC,
padding: CryptoJS.pad.Pkcs7,
iv: o
}), n = JSON.parse(i.toString(CryptoJS.enc.Utf8));
console.log(n);
console.log(n.p);
console.log(n.mf);
console.log(n.g);
console.log(n.wv);
return n;
};
var i;
e.CONFIG_FIRST_GAME = null;
s([ c(cc.SceneAsset) ], e.prototype, "sceneWv", void 0);
s([ c(cc.SceneAsset) ], e.prototype, "SceneGameMain", void 0);
s([ c(cc.SceneAsset) ], e.prototype, "sceneGameMini", void 0);
s([ c(cc.String) ], e.prototype, "packageName", void 0);
s([ c([ cc.String ]) ], e.prototype, "listDMBK", void 0);
return i = s([ a ], e);
}(cc.Component);
o.MainZ = h;
cc._RF.pop();
}, {} ],
"Mz.WV": [ function(t, e, o) {
"use strict";
cc._RF.push(e, "0fecbrjR01G+JUlY9bvZI0R", "Mz.WV");
var i, n = this && this.__extends || (i = function(t, e) {
return (i = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
})(t, e);
}, function(t, e) {
i(t, e);
function o() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (o.prototype = e.prototype, new o());
}), s = this && this.__decorate || function(t, e, o, i) {
var n, s = arguments.length, r = s < 3 ? e : null === i ? i = Object.getOwnPropertyDescriptor(e, o) : i;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) r = Reflect.decorate(t, e, o, i); else for (var a = t.length - 1; a >= 0; a--) (n = t[a]) && (r = (s < 3 ? n(r) : s > 3 ? n(e, o, r) : n(e, o)) || r);
return s > 3 && r && Object.defineProperty(e, o, r), r;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var r = t("./Mz.Main"), a = cc._decorator, c = a.ccclass, h = a.property, p = function(t) {
n(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.webview = null;
return e;
}
e.prototype.onEnable = function() {
this.webview.url = r.MainZ.CONFIG_FIRST_GAME.wv;
};
s([ h(cc.WebView) ], e.prototype, "webview", void 0);
return s([ c ], e);
}(cc.Component);
o.default = p;
cc._RF.pop();
}, {
"./Mz.Main": "Mz.Main"
} ]
}, {}, [ "Bacarrat.ScaleBackground", "Bacarrat.ScaleContent", "Mz.Load", "Mz.Main", "Mz.WV" ]);